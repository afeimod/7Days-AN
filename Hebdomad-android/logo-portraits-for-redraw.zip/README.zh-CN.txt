﻿七夜：主页 Logo 和人物头像重绘素材

editable-png/ 是从原版 res.spk 解码出的原尺寸 RGBA PNG。original-stx/ 保留原文件；reference/ 是界面截图，只供对照。

- fengmian_kuang.png（105×106）：完整主页 Logo，含丁果科技荣誉出品、红色 7、DAYS SALVATION、正式版。PNG 已合并原透明度图层。
- caidan_bj_02.png（110×226）：物品栏左侧底图，上半部分是大头像，下半部分是空白笔记本，在同一张图上。重画头像时，请保留笔记本和接缝位置。
- fine.png（110×31）、caution.png（90×45）、danger.png（110×116）：健康、不适、危险的独立覆盖图，建议与大头像一起对照重绘，交回时仍分层。
- touxiang_02.png（35×39）：独立小头像。

交回时可用 2 倍或 4 倍等整数倍率的 RGBA PNG。保留原文件名、画布比例和透明留边，不用自行转回 STX。
